/**
 * Created by lingxi on 2017/12/20.
 */
module.exports = {
    host: '10.46.64.194',
    database: "hcbtest",
    username: "root",
    password: "Root#209*17",
    port: '3306'
}